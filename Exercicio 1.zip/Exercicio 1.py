#Faça um Programa que peça um número inteiro e determine se ele é par ou impar. Dica:
# utilize o operador módulo (resto da divisão).
Num = int(input('Digite um Numero'))

if Num%2 :
    print("Impar")
else:
    print("Par")








